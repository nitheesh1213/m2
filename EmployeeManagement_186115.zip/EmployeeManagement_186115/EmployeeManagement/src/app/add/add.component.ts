import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import {EmployeeService} from '../employee.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

//EmployeeList : any = [];
Employee:Employee=new Employee();

  constructor(private EmployeeService: EmployeeService){
    //this.EmployeeService.getEmployeeDetails().subscribe(data => this.EmployeeList = data);
}

  ngOnInit() {
  }
  insert(data){console.log(data)
    alert(`id: ${data.id} Name: ${data.name} Email: ${data.email} phone: ${data.phone}`);
    this.Employee.id=data.id;
    this.Employee.name=data.name;
    this.Employee.email=data.email;
    this.Employee.phone=data.phone;
    console.log(this.Employee);
    this.EmployeeService.setEmployeeDetails(this.Employee);
  }
  show(data):void{  
    alert(`Employee Added\nCode: ${data.id} Name: ${data.name} Author: ${data.email} Genre: ${data.phone}`);
  }
  onClickSubmit(d) {
    alert("Entered Email id : " + d.emailid);
  }
}

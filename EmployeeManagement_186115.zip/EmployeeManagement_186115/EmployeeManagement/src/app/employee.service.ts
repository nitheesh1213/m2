import { Injectable } from '@angular/core';
import { Employee } from './employee';
import { HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private httpClient:HttpClient) { 
    
    this.getEmployeeDetails().subscribe(data => this.EmployeeList = data);
  }

  EmployeeList:Array<Employee>=[];
  
  url:string="/assets/employee.json";


  getEmployeeDetails():any{
    return this.httpClient.get<Employee>(this.url);
  }

 
  deleteEmployee(id:number):void{
    let i=0;
    for(let Employee of this.EmployeeList){
      if(Employee.id==id){
        console.log("employee code "+Employee.id);
       console.log(this.EmployeeList.splice(i,1));
      }
      i++;
    }
    
  }

  setEmployeeDetails(Employee:Employee){
      this.EmployeeList.push(Employee);
    
  }




  updateEmployeeDetails(Employee:Employee){
    for(let b of this.EmployeeList){
      if(Employee.id==b.id){
          b.id=Employee.id;
          b.name=Employee.name;
          b.email=Employee.email;
          b.phone=Employee.phone;
      }
    }
    console.log(this.EmployeeList);
  }
}


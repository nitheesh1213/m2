import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { HttpClient} from '@angular/common/http';
import { Employee } from '../employee';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  employeeList:any=[];
  constructor(private employeeService:EmployeeService) { 
    this.employeeList= this.employeeService.EmployeeList;
     
    }

  ngOnInit() {
    this.employeeList= this.employeeService.EmployeeList;
  }
  reload(){
    this.employeeList= this.employeeService.EmployeeList;
  }

  flag=false;
name;id;email;phone;

Employee=new Employee;
  changeFlag(b:Employee){
    this.flag=true;
    this.name=b.name;this.id=b.id;this.email=b.email;this.phone=b.phone;
    

  }
  update
  (f){
   let b:Employee=new Employee;
  b=f;
  console.log(b);
  this.employeeService.updateEmployeeDetails(b);
  }

  delete(code:number){
    this.employeeService.deleteEmployee(code);
    this.employeeList= this.employeeService.EmployeeList;
  }
}

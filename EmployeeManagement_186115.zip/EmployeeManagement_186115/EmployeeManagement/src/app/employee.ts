export class Employee{
    id:number;
    name:string;
    email:any;
    phone:number;
    }